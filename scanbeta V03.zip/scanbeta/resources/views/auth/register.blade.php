@extends('layouts.app')

@section('content')

<div class="">

{{ __('Register') }}
<form method="POST" action="{{ route('register') }}" class="form">
    @csrf

    <div class="">
        <label for="name" class="">{{ __('Nombre') }}</label>
        <div class="">
            <input id="name" type="text" class="input" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>
            @error('name')
                <span class="error" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
        </div>
    </div>

    <div class="">
        <label for="email" class="">{{ __('Correo') }}</label>

        <div class="">
            <input id="email" type="email" class="input" name="email" value="{{ old('email') }}" required autocomplete="email">

            @error('email')
                <span class="error" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
        </div>
    </div>

    <div class="">
        <label for="password" class="">{{ __('Contraseña') }}</label>

        <div class="">
            <input id="password" type="password" class="input" name="password" required autocomplete="new-password">
            @error('password')
                <span class="error" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
        </div>
    </div>

    <div class="">
        <label for="password-confirm" class="">{{ __('Confirmar Contraseña') }}</label>
        <div class="">
            <input id="password-confirm" type="password" class="input" name="password_confirmation" required autocomplete="new-password">
        </div>
    </div>

    <div class="item-der">
        <button type="submit" class="boton boton-azul">
            {{ __('REGISTRAR') }}
        </button>
    </div>
</form>
</div>
@endsection

@extends('layouts.app')

@section('content')
<div>
{{ __('Resetear contraseña') }}

    @if (session('status'))
        <div class="error" role="alert">
            {{ session('status') }}
        </div>
    @endif

    <form method="POST" action="{{ route('password.email') }}" class="form">
        @csrf

        <div class="">
            <label for="email" >{{ __('Correo') }}</label>

            <div>
                <input id="email" type="email" name="email" class="input" value="{{ old('email') }}" required autocomplete="email" autofocus>

                @error('email')
                    <span class="error" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>

        <div class="item-der">
            <button type="submit" class="boton boton-azul">
                {{ __('ENVIAR ENLACE') }}
            </button>
        </div>
    </form>
</div>
@endsection

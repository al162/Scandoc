<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="#">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- <title><?php echo e(config('app.name', 'Laravel')); ?></title> -->
    <title>ScanDoc</title>


    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>

    <nav class="nav">
             
            <!-- Authentication Links -->
        <div class="nav_login">
            <?php if(auth()->guard()->guest()): ?>
            <a class="" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
            <!-- <?php if(Route::has('register')): ?> -->
            <a class="" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
            <?php endif; ?>
            
            <?php else: ?>
            <span><?php echo e(Auth::user()->email); ?></span>
            <!-- <?php echo e(config('app.name', 'Laravel')); ?> -->
            <a href="<?php echo e(route('logout')); ?>" 
                onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
            </form>
            <?php endif; ?>
        </div>        
    </nav>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>
</html>
<?php /**PATH C:\laragon\www\scanbeta\resources\views/layouts/app2.blade.php ENDPATH**/ ?>
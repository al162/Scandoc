<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Codedge\Fpdf\Fpdf\Fpdf;
use Illuminate\Support\Facades\Auth;

class AppController extends Controller
{
    public function home()
    {
        // dump(session()->all());
        $paths = session()->get('paths');
        // dump(Auth::user()->email, $paths);

        return view('home', compact('paths'));
    }
    public function store(Request $request)
    {
        $request->validate(['image' => 'required','image.*' => 'image']);

        if($request->hasFile('image')){
            foreach ($request->file('image') as $image) {
                session()->push('paths', $image->store('public'));
            }
        }
        return back();
    }    
    public function destroy()
    {
        foreach (session()->get('paths') as $image) {
            Storage::delete($image);
        }
        session()->forget('paths');
        return back();
    }
    public function preview()
    {
        $pdf = new FPDF();
        $paths = session()->get('paths');
        foreach ($paths as $image) {
            $pdf->AddPage();
            $pdf->Image($image, 0, 0, 210, 297);
            // tamaño A4
        }

        $namePDF = substr($paths[0], 0, -3)."pdf";
        $pdf->Output('F', $namePDF);

        return view('preview', compact('namePDF'));
    }
    public function destroypdf()
    {
        $namePDF = substr(session()->get('paths')[0], 0, -3)."pdf";
        Storage::delete('public', $namePDF);

        return redirect('/home');
    }    
    public function storebd(Request $request){

        // $path_pdf = substr(session()->get('paths')[0], 0, -3)."pdf";
        $user = Auth::user()->email;
        $categoria = $request->cat;

        $old_path = substr(session()->get('paths')[0], 0, -3)."pdf";
        $name_b = substr($old_path, 7);
        $name_a = $request->name.'.pdf';
        $new_path = 'storage/'.$user.'/'.$name_b;
        
        if($new_path){Storage::delete($new_path);};
        Storage::rename($old_path, $new_path);
        $documento = [
            'usuario' => $user,
            'categoria' => $categoria,
            'nombre' => $name_a,
            'file_path' => $new_path,
        ];

        
        foreach (session()->get('paths') as $image) {
            Storage::delete($image);
        }
        session()->forget('paths');

        return $documento;
    }
}

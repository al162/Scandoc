@extends('layouts.app')

@section('content')        
<div class="cnt-prev">
    <div>
        <!-- Previsualización PDF -->
        <div class="cnt-prev-pdf">
            <iframe src={{$namePDF}} height="100%" width="100%"></iframe>    
        </div>
    </div>
    <div>
        <!-- Almacenar documento -->
        <form method="POST"  class="cnt-prev-form">
            @csrf
            <div>
                <label>Nombre</label>
                <input type="text" class="input" name="name" required>
            </div>
            <select class="input" name="cat" required>
                <option selected="yes" value="" disabled>Categoría</option>
                <option value="Contrato">Contrato</option>
                <option value="Factura">Factura</option>
                <option value="Escritura">Escritura</option>
            </select>
            <div class="item-der">
                <button type="submit" class="boton boton-azul">ALMACENAR</button>
            </div>
        </form>
        <div class="item-der paddin-top">
            <a href="{{ route('destroypdf') }}"><button type="submit" class="boton boton-azul">VOLVER</button></a> 
        </div>
    </div>
</div>

@endsection

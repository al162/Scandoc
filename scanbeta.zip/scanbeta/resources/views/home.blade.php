@extends('layouts.app')

@section('content')
<!-- <div>{{ __('Dashboard') }}</div> -->
<div>
    @if (session('status'))
        <div class="error" role="alert">
            {{ session('status') }}
        </div>
    @endif

<!-- Captura img del documento -->
<div class="cnt-img">
<!-- LISTA IMGNS -->
    @if($paths)
    <div class="cnt-img-box">
        <div class="cnt-img-box-list">
                @foreach ($paths as $file)
                <div>
                    <img src={{ $file }} style="height: 150px;"><br>
                    página {{ $loop->iteration }}
                </div>
                @endforeach
        </div>
        <div class="item-der">
            <a href="{{ route('destroy') }}"><button type="submit" class="boton boton-rojo">BORRAR</button></a> 
        </div>
    </div>
    @endif
<!-- ERROR -->
    @if ($errors->any())
    <div class="">
        @foreach ($errors->all() as $error)
        <div class="error" role="alert">
         {{ $error }}
        </div>
         @endforeach
    </div>
    @endif

<!-- BOTON SeLECCIONAR SUBIR-->
    <form method="POST" enctype="multipart/form-data" class="cnt-img_space-btn">
        @csrf
        <input type="file" name="image[]" multiple id="real-file" hidden="hidden">
        <label type="button" for="real-file" class="boton boton-azul">SELECCIONAR</label>
        <button type="submit" class="boton boton-azul">SUBIR</button>
    </form>

    @if($paths)
    <div class="item-der">
        <a href="{{ route('preview') }}"><button type="submit" class="boton boton-azul">PREVISUALIZAR PDF</button></a> 
    </div>
    @endif

</div>
</div>
@endsection

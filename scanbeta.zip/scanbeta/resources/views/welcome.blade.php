@extends('layouts.app')

@section('content')        

    <!-- <div> -->
    <!-- <a class="main_logo_link" href="{{ url('/home') }}"></a> -->
    <a class="main_logo" href="{{ url('/home') }}">
        <font class="main_logo_font">ScanDoc</font>
        <image class="main_logo_img" src="photo/scanner_PNG101530.png"></image>
        <!-- <image height="80" src="photo/scanner_PNG101530.png"></image> -->
    </a>

<!--     <div class="main_laravel">
        Laravel v{{ Illuminate\Foundation\Application::VERSION }} (PHP v{{ PHP_VERSION }})
    </div> -->

@endsection

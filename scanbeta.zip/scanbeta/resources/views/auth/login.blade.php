@extends('layouts.app')

@section('content')

<div class="">

{{ __('Login') }}
<form method="POST" action="{{ route('login') }}" class="form">
        @csrf

        @error('email')
        <span class="error" role="alert">
            <strong>{{ $message }}</strong>
        </span>
        @enderror
        
        <div class="">
            <label for="email" class="">{{ __('Correo') }}</label>
            <div>
                <input class="input" id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
            </div>
        </div>

        <div class="">
            <label for="password">{{ __('Contraseña') }}</label>
            <div class="">
                <!-- <input id="password" type="password" class=" @error('password') is-invalid @enderror" name="password" required autocomplete="current-password"> -->
                <input class="input" id="password" type="password" name="password" required autocomplete="current-password">
            </div>
        </div>

        <div class="item-izq">
            <input type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
            <label for="remember">{{ __('Recordarme') }}</label>
        </div>

        <div class="item-der">
            @if (Route::has('password.request'))
            <a href="{{ route('password.request') }}">
                {{ __('¿Olvidaste tu contraseña?') }}
            </a>
            @endif
            <button type="submit" class="boton boton-azul">
                {{ __('LOG IN') }}
            </button>
        </div>
</form>
</div>

@endsection
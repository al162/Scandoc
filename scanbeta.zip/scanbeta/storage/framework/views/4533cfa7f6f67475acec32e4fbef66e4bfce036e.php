

<?php $__env->startSection('content'); ?>
<div>
<?php echo e(__('Resetear contraseña')); ?>


    <?php if(session('status')): ?>
        <div class="error" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('password.email')); ?>" class="form">
        <?php echo csrf_field(); ?>

        <div class="">
            <label for="email" ><?php echo e(__('Correo')); ?></label>

            <div>
                <input id="email" type="email" name="email" class="input" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="item-der">
            <button type="submit" class="boton boton-azul">
                <?php echo e(__('ENVIAR ENLACE')); ?>

            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\scanbeta\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>
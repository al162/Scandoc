<?php $__env->startSection('content'); ?>        

    <!-- <div> -->
    <!-- <a class="main_logo_link" href="<?php echo e(url('/home')); ?>"></a> -->
    <a class="main_logo" href="<?php echo e(url('/home')); ?>">
        <font class="main_logo_font">ScanDoc</font>
        <image class="main_logo_img" src="photo/scanner_PNG101530.png"></image>
        <!-- <image height="80" src="photo/scanner_PNG101530.png"></image> -->
    </a>

<!--     <div class="main_laravel">
        Laravel v<?php echo e(Illuminate\Foundation\Application::VERSION); ?> (PHP v<?php echo e(PHP_VERSION); ?>)
    </div> -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\scanbeta\resources\views/welcome.blade.php ENDPATH**/ ?>
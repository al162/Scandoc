

<?php $__env->startSection('content'); ?>

<div class="">

<?php echo e(__('Login')); ?>

<form method="POST" action="<?php echo e(route('login')); ?>" class="form">
        <?php echo csrf_field(); ?>

        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="error" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
        <div class="">
            <label for="email" class=""><?php echo e(__('Correo')); ?></label>
            <div>
                <input class="input" id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
            </div>
        </div>

        <div class="">
            <label for="password"><?php echo e(__('Contraseña')); ?></label>
            <div class="">
                <!-- <input id="password" type="password" class=" <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password"> -->
                <input class="input" id="password" type="password" name="password" required autocomplete="current-password">
            </div>
        </div>

        <div class="item-izq">
            <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
            <label for="remember"><?php echo e(__('Recordarme')); ?></label>
        </div>

        <div class="item-der">
            <?php if(Route::has('password.request')): ?>
            <a href="<?php echo e(route('password.request')); ?>">
                <?php echo e(__('¿Olvidaste tu contraseña?')); ?>

            </a>
            <?php endif; ?>
            <button type="submit" class="boton boton-azul">
                <?php echo e(__('LOG IN')); ?>

            </button>
        </div>
</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\scanbeta\resources\views/auth/login.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<!-- <div><?php echo e(__('Dashboard')); ?></div> -->
<div>
    <?php if(session('status')): ?>
        <div class="error" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

<!-- Captura img del documento -->
<div class="cnt-img">
<!-- LISTA IMGNS -->
    <?php if($paths): ?>
    <div class="cnt-img-box">
        <div class="cnt-img-box-list">
                <?php $__currentLoopData = $paths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <img src=<?php echo e($file); ?> style="height: 150px;"><br>
                    página <?php echo e($loop->iteration); ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="item-der">
            <a href="<?php echo e(route('destroy')); ?>"><button type="submit" class="boton boton-rojo">BORRAR</button></a> 
        </div>
    </div>
    <?php endif; ?>
<!-- ERROR -->
    <?php if($errors->any()): ?>
    <div class="">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="error" role="alert">
         <?php echo e($error); ?>

        </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

<!-- BOTON SeLECCIONAR SUBIR-->
    <form method="POST" enctype="multipart/form-data" class="cnt-img_space-btn">
        <?php echo csrf_field(); ?>
        <input type="file" name="image[]" multiple id="real-file" hidden="hidden">
        <label type="button" for="real-file" class="boton boton-azul">SELECCIONAR</label>
        <button type="submit" class="boton boton-azul">SUBIR</button>
    </form>

    <?php if($paths): ?>
    <div class="item-der">
        <a href="<?php echo e(route('preview')); ?>"><button type="submit" class="boton boton-azul">PREVISUALIZAR PDF</button></a> 
    </div>
    <?php endif; ?>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\scanbeta\resources\views/home.blade.php ENDPATH**/ ?>
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AppController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::view('home', 'home')->middleware('auth');
Route::get('/home', [AppController::class, 'home'])->name('home')->middleware('auth');
Route::post('/home', [AppController::class, 'store']);
Route::get('/delimg', [AppController::class, 'destroy'])->name('destroy')->middleware('auth');
Route::get('/preview', [AppController::class, 'preview'])->name('preview')->middleware('auth');
Route::post('/preview', [AppController::class, 'storebd']);
Route::get('/delpdf', [AppController::class, 'destroypdf'])->name('destroypdf')->middleware('auth');

// Route::get('/storebd', [AppController::class, 'storebd'])->name('storebd')->middleware('auth');



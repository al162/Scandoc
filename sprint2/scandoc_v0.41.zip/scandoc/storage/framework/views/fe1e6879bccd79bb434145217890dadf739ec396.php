<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('SUBIR DOCUMENTO')); ?>

            </style>
   
        </h2>
     <?php $__env->endSlot(); ?>



    <div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6">
<!-- LISTA DE IMAGENES SUBIDAS -->
            <?php if($paths): ?>
            <div class="border bg-gray-200 rounded-md">
                <div class="px-1 py-2 flex-wrap flex gap-1 justify-center ">
                    <?php $__currentLoopData = $paths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border bg-white rounded-md px-4 py-2 ">
                        <img src=<?php echo e($file); ?> style="height: 100px;">
                        página <?php echo e($loop->iteration); ?>

                        <!-- <?php echo e($file); ?> -->
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- BOTON BORRAR-->
                </div>
                <div class="text-right">
                    <a href="<?php echo e(route('destroy')); ?>"><button type="submit" class="px-4 py-2 bg-red-700 border border-transparent rounded-md font-semibold text-xs text-white tracking-widest hover:bg-red-600 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition ml-4">
                    BORRAR</button></a>            
                </div>
            </div>
<!-- CANTIDAD DE PAGINAS-->
               <!--  <div class="text-center"><br>
                    Cantidad de páginas: <?php echo e(count($paths)); ?>

                </div> -->
            <?php endif; ?> 
<!-- ERRORES-->
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="text-center"><br>
                    <?php echo e($error); ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <br>
<!-- BOTONES SELECCIONAR-SUBIR -->
            <form method="POST" enctype="multipart/form-data" class="items-center px-4 py-2 flex justify-center">
                <?php echo csrf_field(); ?>
                <br>
                <input type="file" name="image[]" multiple id="upload" hidden/>
                <!-- <input type="file" name="image[]" multiple id="upload"/> -->
                <label for="upload" class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition ml-4">
                SELECCIONAR</label>
                <!-- <span id="upload">No file chosen</span> -->
                <button type="submit" class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition ml-4">
                SUBIR</button>
            </form>

        </div>
    </div>
</div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>



<?php /**PATH C:\laragon\www\scandoc\resources\views/dashboard.blade.php ENDPATH**/ ?>
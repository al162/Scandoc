<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<?php if($paths): ?>
    <?php $__currentLoopData = $paths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><img src=<?php echo e($file); ?> style="height: 15vw; min-height: 100px;"><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><br><br>

    <?php $__currentLoopData = $paths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($file); ?><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><br><br>    
    Cantidad de páginas: <?php echo e(count($paths)); ?>

<?php endif; ?> <br>
<form method="POST" enctype="multipart/form-data">
    
    <?php echo csrf_field(); ?>
    
    <input type="file" name="image[]" multiple>
    <button type="submit">Subir</button><br>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($error); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</form>
<?php if($paths): ?>
<a href="<?php echo e(route('destroy')); ?>"><button type="submit">Borrar</button></a> 
<?php endif; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\scandoc\resources\views/cargar-archivo.blade.php ENDPATH**/ ?>
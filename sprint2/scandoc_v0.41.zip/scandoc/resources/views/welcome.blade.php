<!DOCTYPE html>
<html lang="es">
<!-- <html lang="{{ str_replace('_', '-', app()->getLocale()) }}"> -->
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>SCANDOC</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
        <style>
        body {
            font-family: 'Nunito', sans-serif;
        }
        nav{
            display: flex;
            width: 100%;
            justify-content: flex-end;
        }
        nav a{
            margin: 9px;
        }
        main{
            display: flex;
            justify-content: center;
            align-items: center;
            flex-flow: column;
            height: 90vh;
        }
        .logo{
            display: flex;
            width: 90%;
            justify-content: center;
        }
        .img{
        }
        </style>
    </head>
    <body class="">
        @if (Route::has('login'))
        <nav>
            <div>
            @auth
                <a href="{{ url('/dashboard') }}" class="">Cargar Imagen</a>
            @else
                <a href="{{ route('login') }}" class="">Log in</a>

                @if (Route::has('register'))
                <a href="{{ route('register') }}" class="">Registro</a>
                @endif
            @endauth 
            </div>
        
        </nav>
        @endif

            <main>

                <div class="logo">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="758" height="100" viewBox="-0.5 -0.5 758 180" content="&lt;mxfile host=&quot;app.diagrams.net&quot; modified=&quot;2021-05-22T05:09:27.686Z&quot; agent=&quot;5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36&quot; etag=&quot;8tneTWpLswNicqlZPHWW&quot; version=&quot;14.7.0&quot; type=&quot;google&quot;&gt;&lt;diagram id=&quot;xJ3PmlIColxY5haHJ23p&quot; name=&quot;Page-1&quot;&gt;zVbfb5swEP5rkLaHRBgHmjwmpGmktVOlTpr6NDlgwKuxmXFaur9+Z2wI5IfUSt20PDTn787n8/fdxfVwXDY3ilTFnUwp9wI/bTy89oJgMUfw1wCvFpjNIwvkiqUWQgfggf2mDvQdumcprUeBWkquWTUGEykETfQII0rJl3FYJvn41Irk9AR4SAg/Rb+zVBcWnQdXB3xLWV50J6NoYT0l6YLdTeqCpPJlAOFrD8dKSm2tsokpN9x1vNh9mwvevjBFhX7Lhl2eYvbof9mWP2/95q7I8bftZGazPBO+dxf2gohDvlUmIS1UrV8dFdGvvewck7oVagkBKPSr5uAFKzffQKFYy6TLBmXZhNbrGOlzB5o2Bi90yQFAYBLOcgF2AtejCoBnqjQDYZbOUbI0NdtXikI1ZNem8mFdSSZ0K3u48sK1ybXX0lbcpq61kk80llxC3rWQgvYlmUNoc5Fh1OsG/U5lSbV6hRC3oVPatTpauPXLoXGiLqYYNM2Vw4jr1bzPfJATDKfoO9QNL6qbsuez4hodJo56oy6nmT4V96hHEsfkMBDPwjma0yH013ppVExGkvEZRDECTMWmACLqSU0Vy8Z1db86HYZG7jdeb1xNXRFx9so7kjzlSu5FOnGJzc1VvvsUhKCXbys9sj+bRVvMEWMBPkeYFwfe8nrAl61mXOEFGgFum+N/GNQPmEn8hpmc/cuZjM7M5BHH8FJUxmRl+zj1hN6SHeX3QJBm0hC7k1rLEgK4caz6xor7hsVZ+zkjipaV4buu7KOZsYZC1av2yGWH+h0CdqG1eXKX5vbBphI5K/NpAscHm33FJUlr02cwqQKaoLd+3H+9QTDX2J/Clo+RNAqPNA0XUxSeyIq6N3ooKwrQNMLvlhaWh4e69Q3+28HXfwA=&lt;/diagram&gt;&lt;/mxfile&gt;"><defs/><g><rect x="0" y="55" width="620" height="70" fill="none" stroke="none" pointer-events="all"/><g transform="translate(-0.5 -0.5)"><switch><foreignObject style="overflow: visible; text-align: left;" pointer-events="none" width="100%" height="100%" requiredFeatures="http://www.w3.org/TR/SVG11/feature#Extensibility"><div xmlns="http://www.w3.org/1999/xhtml" style="display: flex; align-items: unsafe center; justify-content: unsafe center; width: 1px; height: 1px; padding-top: 90px; margin-left: 310px;"><div style="box-sizing: border-box; font-size: 0; text-align: center; "><div style="display: inline-block; font-size: 12px; font-family: Helvetica; color: #000000; line-height: 1.2; pointer-events: all; white-space: nowrap; "><font style="font-size: 150px">ScanDoc</font></div></div></div></foreignObject><text x="310" y="94" fill="#000000" font-family="Helvetica" font-size="12px" text-anchor="middle">ScanDoc</text></switch></g><rect x="10" y="55" width="640" height="70" fill="none" stroke="none" pointer-events="all"/><g transform="translate(-0.5 -0.5)"><switch><foreignObject style="overflow: visible; text-align: left;" pointer-events="none" width="100%" height="100%" requiredFeatures="http://www.w3.org/TR/SVG11/feature#Extensibility"><div xmlns="http://www.w3.org/1999/xhtml" style="display: flex; align-items: unsafe center; justify-content: unsafe center; width: 1px; height: 1px; padding-top: 90px; margin-left: 330px;"><div style="box-sizing: border-box; font-size: 0; text-align: center; "><div style="display: inline-block; font-size: 12px; font-family: Helvetica; color: #000000; line-height: 1.2; pointer-events: all; white-space: nowrap; "><div style="text-align: left"><font color="#45818e" style="font-size: 150px">ScanDoc</font><font face="arial, sans-serif" size="1" color="#45818e"><span style="background-color: rgb(255 , 255 , 255) ; font-size: 23px">®</span></font></div></div></div></div></foreignObject><text x="330" y="94" fill="#000000" font-family="Helvetica" font-size="12px" text-anchor="middle">ScanDoc®</text></switch></g><image x="629.5" y="23.65" width="127" height="121.63" xlink:href="https://pngimg.com/uploads/scanner/scanner_PNG101530.png" preserveAspectRatio="none"/></g><switch><g requiredFeatures="http://www.w3.org/TR/SVG11/feature#Extensibility"/><a transform="translate(0,-5)" xlink:href="https://www.diagrams.net/doc/faq/svg-export-text-problems" target="_blank"><text text-anchor="middle" font-size="10px" x="50%" y="100%">Viewer does not support full SVG 1.1</text></a></switch></svg>
                </div>

                <div class="img">
                <img src="https://www.softpatagonia.com/assets/images/logomenu1.png" alt="sp"/>
                </div>
            </main>
    </body>
</html>

<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('SUBIR DOCUMENTO') }}
            </style>
   
        </h2>
    </x-slot>



    <div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6">
<!-- LISTA DE IMAGENES SUBIDAS -->
            @if($paths)
            <div class="border bg-gray-200 rounded-md">
                <div class="px-1 py-2 flex-wrap flex gap-1 justify-center ">
                    @foreach ($paths as $file)
                    <div class="border bg-white rounded-md px-4 py-2 ">
                        <img src={{ $file }} style="height: 100px;">
                        página {{ $loop->iteration }}
                        <!-- {{ $file }} -->
                    </div>
                    @endforeach
<!-- BOTON BORRAR-->
                </div>
                <div class="text-right">
                    <a href="{{ route('destroy') }}"><button type="submit" class="px-4 py-2 bg-red-700 border border-transparent rounded-md font-semibold text-xs text-white tracking-widest hover:bg-red-600 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition ml-4">
                    BORRAR</button></a>            
                </div>
            </div>
<!-- CANTIDAD DE PAGINAS-->
               <!--  <div class="text-center"><br>
                    Cantidad de páginas: {{ count($paths) }}
                </div> -->
            @endif 
<!-- ERRORES-->
            @if ($errors->any())
                @foreach ($errors->all() as $error)
                <div class="text-center"><br>
                    {{ $error }}
                </div>
                @endforeach
            @endif
            <br>
<!-- BOTONES SELECCIONAR-SUBIR -->
            <form method="POST" enctype="multipart/form-data" class="items-center px-4 py-2 flex justify-center">
                @csrf
                <br>
                <input type="file" name="image[]" multiple id="upload" hidden/>
                <!-- <input type="file" name="image[]" multiple id="upload"/> -->
                <label for="upload" class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition ml-4">
                SELECCIONAR</label>
                <!-- <span id="upload">No file chosen</span> -->
                <button type="submit" class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition ml-4">
                SUBIR</button>
            </form>

        </div>
    </div>
</div>
</x-app-layout>



